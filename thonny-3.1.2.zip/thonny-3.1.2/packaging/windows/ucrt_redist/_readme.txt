all these dlls should go to Thonny root. 
api-ms-win*.dll-s should go also to DLL-s folder

http://blogs.msdn.com/b/vcblog/archive/2015/03/03/introducing-the-universal-crt.aspx
http://stackoverflow.com/questions/31811597/visual-c-2015-redistributable-dlls-for-app-local-deployment