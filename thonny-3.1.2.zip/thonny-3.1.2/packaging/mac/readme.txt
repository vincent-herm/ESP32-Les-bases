For installing, just drag Thonny icon to Desktop or Applications folder.

At first run you may need to Ctrl-click (or right-click) Thonny icon and select "Open".
A confirmation dialog appears -- click "Open" again to run Thonny.
 
For uninstalling, just move Thonny icon to Trash.