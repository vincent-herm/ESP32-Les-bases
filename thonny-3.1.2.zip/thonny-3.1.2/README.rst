======
Thonny
======

Thonny is a Python IDE meant for learning programming.

End users
---------
See https://thonny.org and `wiki <https://github.com/thonny/thonny/wiki>`_ for more info.


Contributors
------------
Contributions are welcome! See `CONTRIBUTING.rst <https://github.com/thonny/thonny/blob/master/CONTRIBUTING.rst>`_ for more info.
