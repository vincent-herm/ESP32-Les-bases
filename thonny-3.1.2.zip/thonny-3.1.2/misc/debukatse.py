def kala(x, y, z):
    print("tere", x)


for x in range(3):
    print(x)

x = 32 / 0
kala(x, x, 1)
kala(4, 2, 1)
print("valma")
