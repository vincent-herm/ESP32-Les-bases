def momo():
    print("momo")


print("momodone")
