from turtle import forward

forward(100)
