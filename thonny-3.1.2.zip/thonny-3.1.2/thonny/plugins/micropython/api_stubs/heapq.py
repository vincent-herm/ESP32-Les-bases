def heapify():
    pass


def heappop():
    pass


def heappush():
    pass
