LANDSCAPE = 1
LANDSCAPE_UPSIDEDOWN = 3


class LCD160CR:
    ""

    def _fcmd2():
        pass

    def _fcmd2b():
        pass

    def _send():
        pass

    def _waitfor():
        pass

    def clip_line():
        pass

    def dot():
        pass

    def dot_no_clip():
        pass

    def erase():
        pass

    def fast_spi():
        pass

    def feed_wdt():
        pass

    def get_line():
        pass

    def get_pixel():
        pass

    def get_touch():
        pass

    def iflush():
        pass

    def is_touched():
        pass

    def jpeg():
        pass

    def jpeg_data():
        pass

    def jpeg_start():
        pass

    def line():
        pass

    def line_no_clip():
        pass

    def oflush():
        pass

    def poly_dot():
        pass

    def poly_line():
        pass

    def rect():
        pass

    def rect_interior():
        pass

    def rect_interior_no_clip():
        pass

    def rect_no_clip():
        pass

    def rect_outline():
        pass

    def rect_outline_no_clip():
        pass

    def reset():
        pass

    def rgb():
        pass

    def save_to_flash():
        pass

    def screen_dump():
        pass

    def screen_load():
        pass

    def set_brightness():
        pass

    def set_font():
        pass

    def set_i2c_addr():
        pass

    def set_orient():
        pass

    def set_pen():
        pass

    def set_pixel():
        pass

    def set_pos():
        pass

    def set_power():
        pass

    def set_scroll():
        pass

    def set_scroll_buf():
        pass

    def set_scroll_win():
        pass

    def set_scroll_win_param():
        pass

    def set_spi_win():
        pass

    def set_startup_deco():
        pass

    def set_text_color():
        pass

    def set_uart_baudrate():
        pass

    def show_framebuf():
        pass

    def touch_config():
        pass

    def write():
        pass


PORTRAIT = 0
PORTRAIT_UPSIDEDOWN = 2
STARTUP_DECO_INFO = 2
STARTUP_DECO_MLOGO = 1
STARTUP_DECO_NONE = 0
_uart_baud_table = None


def calcsize():
    pass


def const():
    pass


machine = None


def pack_into():
    pass


def sleep_ms():
    pass


uerrno = None
