def cos():
    pass


e = 2.718282


def exp():
    pass


def log():
    pass


def log10():
    pass


def phase():
    pass


pi = 3.141593


def polar():
    pass


def rect():
    pass


def sin():
    pass


def sqrt():
    pass
