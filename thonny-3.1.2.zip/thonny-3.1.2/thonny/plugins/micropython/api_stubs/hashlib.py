class sha256:
    ""

    def digest():
        pass

    def update():
        pass
