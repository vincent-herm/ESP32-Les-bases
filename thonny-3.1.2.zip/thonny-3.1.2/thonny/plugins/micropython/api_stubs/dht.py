class DHT11:
    ""

    def humidity():
        pass

    def measure():
        pass

    def temperature():
        pass


class DHT22:
    ""

    def humidity():
        pass

    def measure():
        pass

    def temperature():
        pass


class DHTBase:
    ""

    def measure():
        pass


def dht_readinto():
    pass
