This directory contains licenses of Thonny's dependecies
(which are not necessarily distributed together with Thonny).