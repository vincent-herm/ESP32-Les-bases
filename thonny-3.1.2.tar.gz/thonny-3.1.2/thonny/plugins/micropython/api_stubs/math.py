def acos():
    pass


def acosh():
    pass


def asin():
    pass


def asinh():
    pass


def atan():
    pass


def atan2():
    pass


def atanh():
    pass


def ceil():
    pass


def copysign():
    pass


def cos():
    pass


def cosh():
    pass


def degrees():
    pass


e = 2.718282


def erf():
    pass


def erfc():
    pass


def exp():
    pass


def expm1():
    pass


def fabs():
    pass


def floor():
    pass


def fmod():
    pass


def frexp():
    pass


def gamma():
    pass


def isfinite():
    pass


def isinf():
    pass


def isnan():
    pass


def ldexp():
    pass


def lgamma():
    pass


def log():
    pass


def log10():
    pass


def log2():
    pass


def modf():
    pass


pi = 3.141593


def pow():
    pass


def radians():
    pass


def sin():
    pass


def sinh():
    pass


def sqrt():
    pass


def tan():
    pass


def tanh():
    pass


def trunc():
    pass
