def alloc_emergency_exception_buf():
    pass


def const():
    pass


def heap_lock():
    pass


def heap_unlock():
    pass


def kbd_intr():
    pass


def mem_info():
    pass


def opt_level():
    pass


def qstr_info():
    pass


def schedule():
    pass


def stack_use():
    pass
