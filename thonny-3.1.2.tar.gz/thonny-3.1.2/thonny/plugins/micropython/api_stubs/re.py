DEBUG = 4096


def compile():
    pass


def match():
    pass


def search():
    pass
