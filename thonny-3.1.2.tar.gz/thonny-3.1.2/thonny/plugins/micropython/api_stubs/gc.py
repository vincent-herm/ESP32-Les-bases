def collect():
    pass


def disable():
    pass


def enable():
    pass


def isenabled():
    pass


def mem_alloc():
    pass


def mem_free():
    pass


def threshold():
    pass
