import sys

print(sys.argv)
print(sys.path)
