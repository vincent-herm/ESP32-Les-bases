#!/usr/bin/env bash

rm -rf $target_dir
rm -f $menu_dir/Thonny.desktop
rm -f ~/Desktop/Thonny.desktop

echo "Thonny is successfully uninstalled."
